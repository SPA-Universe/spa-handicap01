// Skin specific Javascript
if ("scImageMgr" in window) scImageMgr.fOverAlpha=.9;
if ("searchMgr" in window) searchMgr.fPathSchParent= "ide:header";

(function (){
	// si le thème du localstorage est dark ...
	if (localStorage.getItem("theme") == "dark") {
	  // ... alors on met la classe dark-theme au body
	  document.body.classList.add("dark-theme");
	} else if (localStorage.getItem("theme")==null){
		// ... on interroge le thème du navigateur
		const prefersDarkScheme = window.matchMedia("(prefers-color-scheme: dark)");

		if (prefersDarkScheme.matches) {
			// si c'est dark alors on met la classe dark-theme au body
			document.body.classList.add("dark-theme");
		} else {
			// sinon, on l'enlève
			document.body.classList.remove("dark-theme");
		}
	}
	// si le mode du localstorage est dys ...
	if (localStorage.getItem("mode") == "dys") {
	  // ... alors on met la classe mode-dys au body
	  document.body.classList.add("mode-dys");
	}
	// si l'état du localstorage est visibles ...
	if (localStorage.getItem("visu") == "btnvisu-on") {
	  // ... alors on met la classe boutonsvisu-on au body
	  document.body.classList.add("boutonsvisu-on");
	}
	// si le titre est déplié ...
	if (localStorage.getItem("titleState") == "titreDeplie") {
	  // ... alors on met la classe titreDeplie au body
	  document.body.classList.add("titreDeplie");
	}
})();

if (!(document.body.classList.contains('subWin'))){
scOnLoads[scOnLoads.length] = {
	loadSortKey: "zzzzskin", 
    onLoad : function(){

		// changement du texte de la boîte de recherche

		scPaLib.findNode("des:input.schInput")?scPaLib.findNode("des:input.schInput").placeholder="RECHERCHER DANS LA RESSOURCE":null;
		
		// réorganisation des blocs et création des nouveaux éléments

		var vDivTopEntete=document.createElement("div");
		vDivTopEntete.setAttribute('class', 'topEntete');
		var vDivOutilsVisu=document.createElement("div");
		vDivOutilsVisu.setAttribute('class', 'outilsVisu');
		vDivTopEntete.appendChild(vDivOutilsVisu);
		var vBoutonTheme=document.createElement("a");
		vBoutonTheme.setAttribute('class', 'boutonTheme');
		vBoutonTheme.innerHTML="Basculer en thème clair/sombre";

		var vBoutonMode=document.createElement("a");
		vBoutonMode.setAttribute('class', 'boutonMode');
		vBoutonMode.innerHTML="Utiliser ou pas une police dys";

		vDivOutilsVisu.appendChild(vBoutonTheme);
		vDivOutilsVisu.appendChild(vBoutonMode);

		var vBoutonCacheOutilsVisu=document.createElement("a");
		vBoutonCacheOutilsVisu.setAttribute('class', 'boutonCacheOutilsVisu');
		vBoutonCacheOutilsVisu.innerHTML="Masquer/Montrer les boutons de visualisation";

		vDivTopEntete.appendChild(vBoutonCacheOutilsVisu);

		var vBoutonTailleTitre=document.createElement("a");
		vBoutonTailleTitre.setAttribute('class', 'boutonTailleTitre');
		vBoutonTailleTitre.innerHTML="Modifier la taille du titre";

		// en fonction de si on est sur une page de contenu ou sur la home, on place les boutons à des endroits différents
		if(scPaLib.findNode("ide:header")){
			var vHeader=scPaLib.findNode("ide:header");
			var vNavAccess=vHeader.lastChild;
			vHeader.firstChild.appendChild(vBoutonTailleTitre);
			vDivTopEntete.appendChild(vNavAccess);
			vHeader.insertBefore(vDivTopEntete, vHeader.firstChild);			
		}else if (scPaLib.findNode("des:body.home/ide:navigation/des:ul")){
			var vUlNavHome=scPaLib.findNode("des:body.home/ide:navigation/des:ul");
			vUlNavHome.insertBefore(vDivOutilsVisu, vUlNavHome.firstChild);
		}else null;

		var vDivPageTurner=scPaLib.findNode("des:nav.pageTurner");
		scPaLib.findNode("ide:content").appendChild(vDivPageTurner);

		// mode clair/sombre
		// on écoute le clic sur le bouton de changement de thème 
		vBoutonTheme.addEventListener("click", function() {
		  // sur chaque clic on met ou enlève la classe dark-theme
		  document.body.classList.toggle("dark-theme");

		  // disons que le thème est light par défaut
		  let theme = "light";
		  // si le body a la classe dark-theme ...
		  if (document.body.classList.contains("dark-theme")) {
		    // ...alors la var theme devient dark
		    theme = "dark";
		  }
		  // on enregistre le thème dans le localstorage
		  localStorage.setItem("theme", theme);
		});

		// on écoute le clic sur le bouton de changement de mode 
		vBoutonMode.addEventListener("click", function() {
		  // sur chaque clic on met ou enlève la classe mode-dys
		  document.body.classList.toggle("mode-dys");
		  
		  // disons que le mode est pas dys par défaut
		  let mode = "nodys";
		  // si le body a la classe mode-dys ...
		  if (document.body.classList.contains("mode-dys")) {
		    // ...alors la var theme devient dys
		    mode = "dys";
		  }
		  // on enregistre le thème dans le localstorage
		  localStorage.setItem("mode", mode);
		});

		// on écoute le clic sur le bouton 
		vBoutonCacheOutilsVisu.addEventListener("click", function() {
		  // sur chaque clic on met ou enlève la classe boutonsvisu-on
		  document.body.classList.toggle("boutonsvisu-on");
		  
		  // disons que les boutons de visualisation ne sont pas visibles par défaut
		  let visu = "btnvisu-off";
		  // si le body a la classe boutonsvisu-on ...
		  if (document.body.classList.contains("boutonsvisu-on")) {
		    // ...alors la var theme devient btnvisu-on
		    visu = "btnvisu-on";
		  }
		  // on enregistre l'état dans le localstorage
		  localStorage.setItem("visu", visu);
		});

		// on écoute le clic sur le bouton 
		vBoutonTailleTitre.addEventListener("click", function() {
		  // sur chaque clic on met ou enlève la classe titreDeplie
		  document.body.classList.toggle("titreDeplie");
		  
		  // disons que le titre est plié par défaut
		  let titleState = "titrePlie";
		  // si le body a la classe titreDeplie ...
		  if (document.body.classList.contains("titreDeplie")) {
		    // ...alors la var theme devient titreDeplie
		    titleState = "titreDeplie";
		  }
		  // on enregistre l'état dans le localstorage
		  localStorage.setItem("titleState", titleState);
		});	
	}
}

}